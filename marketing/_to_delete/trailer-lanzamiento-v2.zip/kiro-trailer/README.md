# Tráiler de lanzamiento de Kiro — «Todo comienza con un punto»

Video vertical 1080 × 1920, 30 fps, H.264 + AAC, para Reels y TikTok.

**Versión actual: v2** (`out/kiro-trailer-v2.mp4`, 41,6 s). El espectador
descubre primero el problema, después la solución y al final la marca: el logo
aparece una sola vez, en los últimos segundos.

| Escena | Tiempo | Qué pasa |
|---|---|---|
| 1 Intriga | 0–5 s | El cuadrado violeta aparece en la oscuridad y parpadea. «Todo negocio empieza con una idea.» |
| 2 Tensión | 5–15 s | El cuadrado activa hojas de cálculo, chats, pendientes y registros que se acumulan y se aceleran. |
| 3 Pausa | 15–18,6 s | Corte seco, todo se retira, silencio real. «Hay otra forma.» |
| 4 Solución | 18,6–29,4 s | El cuadrado traza la guía y ordena el espacio; se vuelve la respuesta del agente y la celda reservada. Sin marca. |
| 5 Revelación | 29,4–36,4 s | La interfaz converge en el cuadrado, que viaja al centro y se queda solo; luego se transforma en «kiro» (única vez). «Kiro.» |
| 6 Cierre | 36,4–41,6 s | El logo queda quieto; entran la frase y la dirección web. Parpadeo y firma sonora. |

La v1 (`out/kiro-trailer.mp4`, logo a mitad de video) se conserva intacta.

## Archivos

| Ruta | Qué es |
|---|---|
| `out/kiro-trailer-v2.mp4` | **Video actual (v2)** |
| `out/hoja-de-contacto-v2.png` | Un fotograma por segundo de la v2 |
| `out/kiro-trailer.mp4` | v1 (referencia; no se sobrescribe) |
| `out/animatic.mp4`, `out/hoja-de-contacto.png` | Pruebas de la v1 |
| `audio/voz/brian/` | Narración usada (ElevenLabs v3, voz «Brian») |
| `audio/voz/george/` | Mismas frases con la voz alternativa «George» |
| `audio/voz/pruebas/` | Las dos pruebas cortas de voz |
| `audio/stems/` | `voz.wav`, `musica.wav`, `efectos.wav`, `mezcla.wav` |
| `config.py` | **Todo lo editable**: tiempos, textos, colores, voz, CTA |
| `lib/logo.py` | Lee la geometría del logo oficial desde `brand/` |
| `lib/timeline.py` | Eventos derivados (movimientos, cues de sonido) |
| `scenes/` | Una pieza por escena: cursor, trabajo manual (E2–E4), transformación (E5), sistema (E6), firma (E7), subtítulos |
| `audio/build_audio.py` | Diseño sonoro, música, mezcla y sonoridad |

## Cómo se ejecuta

Requisitos: Python 3.11+ y FFmpeg en el PATH.

```bash
pip install -r requirements.txt
python build.py              # audio + video → out/kiro-trailer-<VERSION>.mp4  (≈1 min)
python build.py --animatic   # solo 0–24 s → out/animatic.mp4
python render.py --frames 2.5 21.9 38   # fotogramas sueltos en out/frames/
python audio/build_audio.py  # solo rehace el audio
```

El render es determinista: no hay azar ni temporizadores. Imagen y sonido
leen la misma línea de tiempo (`config.T` → `lib/timeline.py`), así que si
mueves un tiempo en `config.py`, se mueven juntos.

## Cambios frecuentes

- **Cambiar de voz:** `VOICE = "george"` en `config.py` y `python build.py`.
- **Otra toma de voz:** reemplaza el `.mp3` en `audio/voz/brian/` con el
  mismo nombre. Si la nueva toma dura distinto, ajusta el cue en `config.T`.
- **Dirección web del cierre:** `URL` en `config.py` (hoy
  kiro.kirosolutionsco.workers.dev).
- **Nueva versión sin pisar la anterior:** cambia `VERSION` en `config.py`.
- **Subtítulos:** `SUBTITULOS = False` los quita.
- **Textos de la demo** (Casa Ceiba, mensajes, panel): `DEMO` en `config.py`.

## Decisiones de producción

- **Logo:** no se redibujó ninguna letra. `lib/logo.py` lee los trazados de
  `brand/kiro-logo-principal-negativo.svg` (el del manual) y la animación solo
  decide cómo se revelan. El fotograma final es idéntico al SVG oficial,
  incluido el gris `#B9B3C4` de «solutions».
- **Transformación:** el cuadrado salta, se duplica y su copia cae para
  escribir el palo de la «i»; los bordes de ese palo se extienden como línea
  base y altura x; sobre esas guías se levantan la K, la r y la o, cada una con
  un filo violeta en el borde que avanza; las guías vuelven a la «i» y el
  cursor parpadea una vez. La cámara se acerca en el silencio y se aleja
  mientras se arma la palabra.
- **Violeta = Kiro actuando:** en la demo, el cuadrado se expande y se vuelve
  la respuesta del agente, luego viaja por el conector y termina siendo la
  celda reservada. En el cierre esa celda vuelve a su sitio en el logo.
- **Render:** Python + Skia (dibujo vectorial con antialiasing) y FFmpeg. Se
  eligió sobre Remotion porque el repo de la landing es Astro (no React) y
  así no hace falta un navegador para renderizar.
- **Sonido:** música y efectos se sintetizan en `audio/build_audio.py` con
  NumPy: son originales, sin licencias de terceros. La firma sonora es un
  «ping» de cursor (La5) sobre un acorde abierto de Re; suena al aparecer el
  cuadrado, cuando la palabra queda completa y al cerrar. En el freeze de E4
  el sonido se corta en seco (sin cola de reverberación) y la música baja
  sola cuando habla el narrador. Mezcla final a −14 LUFS, pico −1,5 dBFS.
- **Voz:** ElevenLabs v3 a través de CoDesign (IMG.LY). Se probaron Brian y
  George; quedó Brian por ser más grave (≈90 Hz frente a ≈125 Hz) y más
  pausado. Cada frase es un archivo aparte, con indicaciones de actuación.
  Las transcripciones confirmaron que el español sale limpio y que «Kiro» se
  pronuncia bien.

## Limitaciones y pendientes

1. **Escuchar la voz.** Las voces de ElevenLabs son anglófonas hablando
   español: pueden tener un leve acento. Revisa Brian y George con audífonos;
   si ninguna convence, la mejor opción es grabar a un locutor colombiano y
   reemplazar los `.mp3` (mismos nombres).
2. **Licencia de la voz.** Se generó con la cuenta de IMG.LY. Confirma en sus
   términos (y los de ElevenLabs) el uso comercial antes de pautar.
3. **Dominio.** El cierre muestra la dirección de workers.dev; cámbiala en
   `URL` cuando haya dominio propio.
4. **Duración.** La v2 dura 41,6 s (meta 35–40) para no apurar la voz ni la
   revelación; se puede recortar moviendo los tiempos de `config.T`.
6. **Frase de la escena 2 (v2).** La narración propuesta era «…de hacerlo a
   mano, cada tarea se convierte en otra complicación.», pero los créditos de
   IMG.LY se agotaron antes de generarla. Por eso la escena 2 usa las dos
   tomas existentes («…de hacerlo a mano…» + «El crecimiento no debería
   significar más complicaciones.»). Para cambiarla: genera la toma, guárdala
   como `audio/voz/brian/02-a-mano.mp3`, quita la línea `03` de `VO` y de
   `SUBTITULOS_EN` en `config.py`, y ajusta `vo2`/`freeze` en `config.T`.
7. **Cierre sin repetir el nombre.** «Software a la medida que trabaja por ti»
   es la toma 07 recortada desde «Software» (`07b-software.mp3`), porque el
   nombre ya se dice en la revelación.
5. **Demo.** «Casa Ceiba» es un negocio de muestra, igual que en la landing.
