"""Subtítulos discretos: cada palabra se enciende cuando el narrador la dice.
Sirven para quien ve el video sin sonido (Reels y TikTok arrancan mudos)."""
import config as cfg
from lib import ease as E
from lib.draw import draw_text, font, text_width

C, T = cfg.C, cfg.T
BASE_Y = 1560
LINE_H = 56
MAX_W = 960
FONT = ("mont600", 38)


def _layout(words, fnt):
    lines, cur, w = [], [], 0
    space = fnt.measureText(" ")
    for wd, tt in words:
        ww = fnt.measureText(wd)
        if cur and w + space + ww > MAX_W:
            lines.append(cur)
            cur, w = [], 0
        cur.append((wd, tt, ww))
        w += (space if len(cur) > 1 else 0) + ww
    if cur:
        lines.append(cur)
    return lines, space


def draw(c, t):
    if not cfg.SUBTITULOS:
        return
    fnt = font(*FONT)
    for fname, cue, text, words in cfg.VO:
        if cue not in cfg.SUBTITULOS_EN:
            continue
        start = T[cue]
        if cfg.VOICE != "brian":       # sin tiempos medidos: reparto uniforme
            n = len(words)
            words = [(w, 0.15 + i * 1.8 / max(1, n)) for i, (w, _) in enumerate(words)]
        end = start + words[-1][1] + 0.9
        if not (start - 0.1 <= t <= end + 0.5):
            continue
        out = E.prog(t, end, end + 0.45)
        lines, space = _layout(words, fnt)
        y = BASE_Y - (len(lines) - 1) * LINE_H / 2
        for ln in lines:
            total = sum(w for _, _, w in ln) + space * (len(ln) - 1)
            x = 540 - total / 2
            for wd, tt, ww in ln:
                k = E.prog(t, start + tt - 0.05, start + tt + 0.12)
                if k > 0:
                    rise = (1 - E.out_cubic(k)) * 10
                    draw_text(c, wd, x, y + rise, fnt, C["white"], 0.88 * k * (1 - out))
                x += ww + space
            y += LINE_H
