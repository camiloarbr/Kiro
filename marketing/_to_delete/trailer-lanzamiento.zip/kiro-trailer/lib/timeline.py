"""Línea de tiempo derivada: posiciones del cursor, eventos de cada escena y
cues de sonido. La imagen y el audio leen este mismo módulo, así que siempre
quedan sincronizados (sin temporizadores ni azar)."""
import config as cfg
from lib import logo as L

T = cfg.T
S = cfg.LOGO_SCALE

# ── Transformación logo (unidades SVG) → pantalla ───────────────────────
_LOGO_UNITS_CENTER = ((L.LEFT + L.RIGHT) / 2, (L.CURSOR.top() + 994.0) / 2)
LOGO_OX = cfg.LOGO_CENTER[0] - _LOGO_UNITS_CENTER[0] * S
LOGO_OY = cfg.LOGO_CENTER[1] - _LOGO_UNITS_CENTER[1] * S


def to_screen(ux, uy):
    return (LOGO_OX + ux * S, LOGO_OY + uy * S)


CURSOR_PX = L.CURSOR_SIDE * S                         # ~62 px
HOME = to_screen(L.CURSOR.centerX(), L.CURSOR.centerY())  # sitio del cursor en el logo

# ── Escenas 2–3: fragmentos de trabajo manual ───────────────────────────
ANCHORS = dict(
    sheet=(977, 706),
    chat=(110, 1030),
    todo=(600, 1178),
    log=(118, 390),
    chat2=(110, 1370),
)

# Movimientos del cursor en E2: (sale, llega, destino, evento que dispara)
S2_MOVES = [
    (4.75, 5.30, "sheet"),
    (5.75, 6.30, "chat"),
    (6.75, 7.30, "todo"),
    (7.75, 8.30, "log"),
    (8.65, 9.15, "chat2"),
]

# E3: el cursor va y viene cada vez más rápido y luego se frena
_S3_CYCLE = ["sheet", "chat", "todo", "log", "chat2", "sheet", "todo", "chat",
             "log", "sheet", "chat2", "todo", "chat", "sheet", "log", "chat2"]


def _s3_moves():
    moves, t, i = [], T["s3"] - 0.1, 0
    while True:
        # intervalo: se acorta hasta T['slow'] y luego se alarga (frenado)
        if t < T["slow"]:
            k = (t - T["s3"]) / (T["slow"] - T["s3"])
            interval = 0.62 - 0.33 * max(0.0, min(1.0, k))
        else:
            k = (t - T["slow"]) / (T["freeze"] - T["slow"])
            interval = 0.29 + 0.45 * k * k
        travel = interval * 0.72
        arrive = t + travel
        if arrive > T["freeze"] - 0.12:
            break
        moves.append((t, arrive, _S3_CYCLE[i % len(_S3_CYCLE)]))
        t += interval
        i += 1
    return moves


S3_MOVES = _s3_moves()
ALL_MOVES = S2_MOVES + S3_MOVES

# Contenidos que se acumulan
SHEET_HEAD = ["HUÉSPED", "FECHA", "ESTADO"]
SHEET_ROWS = [
    ["Laura M.", "sáb", "¿pagó?"], ["Andrés P.", "vie", "pendiente"], ["—", "dom", "llamar"],
    ["Sofía R.", "sáb", "¿?"], ["Grupo 4", "vie", "cotizar"], ["Juan C.", "sáb", "pendiente"],
    ["—", "dom", "¿confirmó?"], ["Marta L.", "vie", "llamar"], ["Pedro A.", "sáb", "¿?"],
]
CHAT_MSGS = [   # pares: chat principal · impares: chat de abajo (cortos)
    "¿Tienen cupo el sábado?", "¿Me confirmas?", "¿Sigue disponible?", "Hola??",
    "¿Aceptan transferencia?", "¿Me respondes?", "¿A qué hora es el check-in?", "¿Hay parqueadero?",
]
LOG_LINES = [
    "› copiar datos del huésped", "› registro_FINAL_v3.xlsx", "› llamar a confirmar",
    "› pasar pago a mano", "› registro_FINAL_v4.xlsx", "› revisar WhatsApp",
    "› copiar datos otra vez",
]
TODO_ITEMS = ["Confirmar por WhatsApp", "Pasar a Excel", "Enviar cotización"]
BADGE_STEPS = [1, 3, 6, 11, 19, 27, 38, 54, 71]


def arrivals(kind, t):
    """Cuántas veces ha llegado el cursor al elemento `kind` hasta t."""
    return sum(1 for (_, a, k) in ALL_MOVES if k == kind and a <= t)


def first_arrival(kind):
    return min(a for (_, a, k) in ALL_MOVES if k == kind)


# ── E4: retirada ─────────────────────────────────────────────────────────
S4_ORDER = ["chat2", "log", "todo", "chat", "sheet"]   # orden en que desaparecen
S4_START = T["s4"] + 0.25
S4_STAGGER = 0.16
S4_DUR = 0.42
S4_CURSOR_HOME = (T["s4"] + 0.35, T["s4"] + 1.45)

# ── E5: transformación (segundos desde T['s5']) ─────────────────────────
S5 = dict(
    hop=(0.00, 0.55),        # anticipación: sube y cae
    extrude=(0.45, 1.05),    # el cuadrado se duplica y cae formando el palo de la i
    guides=(0.95, 1.45),     # los bordes del palo se extienden: línea base y altura x
    k_stem=(1.20, 1.65),
    asc=(1.42, 1.80),        # línea de ascendentes
    k_arm=(1.50, 1.88),
    k_leg=(1.62, 2.00),
    r_stem=(1.72, 2.08),
    r_shoulder=(1.98, 2.32),
    o=(1.86, 2.55),
    retract=(2.45, 2.90),
    blink=(3.15, 3.38),      # el cursor parpadea una vez cuando todo encaja
    solutions=(3.30, 4.10),
)
S5_DONE = 3.0                # = T['logo_done'] - T['s5']

# ── E6: el sistema en acción (segundos desde T['s6']) ───────────────────
S6 = dict(
    logo_out=(0.00, 0.70),
    cursor_to_chat=(0.55, 1.35),
    header=(0.70, 1.10),
    msg1=(0.95, 1.30),
    typing=(1.45, 2.25),     # el cursor «piensa»: late como un indicador de escritura
    bot=(2.25, 2.80),        # el cuadrado se expande y se vuelve la respuesta
    msg2=(3.75, 4.10),
    cursor_out=(4.10, 4.50), # sale de la burbuja y va a la confirmación
    chip=(4.50, 4.95),
    panel=(4.55, 5.20),
    wire=(5.00, 5.75),       # conector chip → celda
    land=(5.75, 6.05),       # el cuadrado se vuelve la celda reservada
    paid=(6.45, 6.85),
)

# ── E7: firma (segundos desde T['s7']) ──────────────────────────────────
S7 = dict(
    ui_out=(0.00, 0.80),
    cursor_home=(0.35, 0.90),
    rebuild=(0.85, 1.55),    # el logo se arma de nuevo, más rápido
    solutions=(1.55, 2.15),
    line1=(T["vo7"] + 1.12 - T["s7"], T["vo7"] + 1.62 - T["s7"]),
    line2=(T["vo7"] + 2.95 - T["s7"], T["vo7"] + 3.45 - T["s7"]),
    cta=(T["vo7"] + 4.40 - T["s7"], T["vo7"] + 5.0 - T["s7"]),
    blink=(T["sting"] - T["s7"], T["sting"] - T["s7"] + 0.26),
)


# ── Cues de sonido (los lee audio/build_audio.py) ───────────────────────
def sound_cues():
    cues = []
    a = cues.append
    a((T["cursor_on"], "cursor_on"))
    # parpadeos audibles muy suaves en E1
    for k in range(2):   # coincide con los apagados del parpadeo (scenes/cursor.py)
        a((T["cursor_on"] + 0.75 + 1.1 * k + 0.68, "blink_soft"))
    # E2–E3: cada llegada del cursor activa algo
    for (dep, arr, kind) in ALL_MOVES:
        a((dep, "move"))
        a((arr, "activate_" + ("chat" if kind.startswith("chat") else kind)))
    a((T["freeze"], "freeze"))
    # E5
    s5 = T["s5"]
    a((s5 + S5["hop"][0], "lift"))
    a((s5 + S5["extrude"][0], "extrude"))
    a((s5 + S5["guides"][0], "guides"))
    for key, note in (("k_stem", 0), ("k_arm", 1), ("k_leg", 2), ("r_stem", 3), ("o", 4)):
        a((s5 + S5[key][0], f"build_{note}"))
    a((s5 + S5["retract"][0], "retract"))
    a((T["logo_done"], "impact"))
    a((s5 + S5["blink"][0], "blink"))
    # E6
    s6 = T["s6"]
    a((s6 + S6["logo_out"][0], "dissolve"))
    a((s6 + S6["msg1"][0], "msg_in"))
    for k in range(4):
        a((s6 + S6["typing"][0] + k * 0.2, "type_tick"))
    a((s6 + S6["bot"][0], "bot_out"))
    a((s6 + S6["msg2"][0], "msg_in"))
    a((s6 + S6["chip"][0], "confirm"))
    a((s6 + S6["wire"][0], "wire"))
    a((s6 + S6["land"][0], "land"))
    a((s6 + S6["paid"][0], "ok"))
    # E7
    s7 = T["s7"]
    a((s7 + S7["ui_out"][0], "dissolve"))
    a((s7 + S7["rebuild"][0], "rebuild"))
    a((s7 + S7["rebuild"][1], "impact_small"))
    a((T["sting"], "sting"))
    return sorted(cues)
