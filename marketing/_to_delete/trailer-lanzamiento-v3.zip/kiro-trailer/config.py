"""Configuración editable del tráiler «Todo comienza con un punto».

Todo lo que normalmente se querría cambiar vive aquí: tiempos, textos,
colores, voz y salida. La animación (render.py) y el audio (audio/build_audio.py)
leen ESTE archivo, así que un cambio de tiempo mueve imagen y sonido juntos.
"""

# ── Salida ───────────────────────────────────────────────────────────────
VERSION = "v3"           # nombre del render: out/kiro-trailer-v3.mp4 (no pisa versiones anteriores)
W, H = 1080, 1920
FPS = 30
DURATION = 38.0          # segundos totales (incluye la cola de silencio)

# ── Voz ──────────────────────────────────────────────────────────────────
# Carpeta dentro de audio/voz/. v3: «claude» (Piper es_MX, masculina, español
# latino neutro; la genera audio/tts_piper.py). Alternativas: «ald» (Piper
# es_MX) y las tomas de ElevenLabs «brian» / «george» de la v1–v2.
VOICE = "claude"

# ── Paleta oficial (manual de marca v1.0) ────────────────────────────────
C = dict(
    violet="#8B2CF5",       # Kiro Violet: cursor y acciones de Kiro (máx. 10 %)
    violet_dark="#5B17B8",
    violet_light="#B07CFF", # texto de acento sobre negro
    black="#0C0A10",        # fondo
    graphite="#1F1A27",     # superficies
    graphite_2="#2A2433",   # superficies elevadas (derivado de grafito)
    gray="#918A9E",         # texto secundario
    white="#F6F4FA",        # texto
    lav="#D9C4FF",          # lavanda media (extensión web aprobada)
)

# ── Línea de tiempo (segundos) ───────────────────────────────────────────
# v2: el logo solo aparece al final. Orden: problema → solución → marca.
T = dict(
    cursor_on=1.20,     # E1 intriga: aparece el cuadrado, en el centro
    vo1=2.30,           # «Todo negocio empieza con una idea.»
    s2=5.20,            # E2 tensión: el cuadrado empieza a activar cosas
    vo2=5.80,           # «Pero cuando todo depende de hacerlo a mano,»
    s3=9.20,            # la complejidad se acumula
    vo3=9.30,           # «cada tarea se convierte en otra complicación.»
    slow=12.90,         # el movimiento empieza a frenarse
    freeze=14.40,       # corte: todo se detiene
    s4=14.40,           # E3 pausa: se retira todo, silencio real
    vo4=15.90,          # «Hay otra forma.»
    s6=18.00,           # E4 la solución: el cuadrado ordena el espacio y trabaja
    vo6a=18.80,         # «Creamos software a tu medida, automatizaciones, y agentes inteligentes,»
    vo6b=24.45,         # «para que tu negocio trabaje mejor.»
    rv=28.00,           # E5 revelación: la interfaz converge en el cuadrado
    s5=30.40,           # el cuadrado empieza a transformarse (única vez)
    logo_done=33.40,    # «kiro» queda completo (impacto)
    vo5=33.95,          # «Kiro.»  (el cierre solo dice el nombre)
    close=35.00,        # el logo queda quieto; entra la dirección web
    sting=36.55,        # firma sonora final (parpadeo del cursor)
)

# ── Narración ────────────────────────────────────────────────────────────
# (archivo en audio/voz/<VOICE>/, cue de inicio, texto, palabras con tiempos
#  relativos de la toma «brian» medidos con ElevenLabs Scribe; con otra voz
#  los subtítulos se reparten solos a lo largo de la frase).
VO = [
    ("01-idea.mp3", "vo1", "Todo negocio empieza con una idea.",
     [("Todo", .12), ("negocio", .36), ("empieza", .96), ("con", 1.40), ("una", 1.72), ("idea.", 2.0)]),
    ("02-a-mano.mp3", "vo2", "Pero cuando todo depende de hacerlo a mano,",
     [("Pero", .13), ("cuando", .39), ("todo", 1.01), ("depende", 1.35), ("de", 1.79), ("hacerlo", 2.05), ("a", 2.39), ("mano,", 2.57)]),
    ("03-crecimiento.mp3", "vo3", "cada tarea se convierte en otra complicación.",
     [("cada", .06), ("tarea", .28), ("se", .72), ("convierte", 1.04), ("en", 1.64), ("otra", 2.10), ("complicación.", 2.34)]),
    ("04-otra-forma.mp3", "vo4", "Hay otra forma.",
     [("Hay", .08), ("otra", .36), ("forma.", .62)]),
    ("05-kiro.mp3", "vo5", "Kiro.", [("Kiro.", .09)]),
    ("06a-creamos.mp3", "vo6a", "Creamos software a tu medida, automatizaciones y agentes inteligentes,",
     [("Creamos", .10), ("software", .52), ("a", .92), ("tu", 1.12), ("medida,", 1.24), ("automatizaciones", 2.08), ("y", 3.14), ("agentes", 3.72), ("inteligentes,", 4.10)]),
    ("06b-para-que.mp3", "vo6b", "para que tu negocio trabaje mejor.",
     [("para", .10), ("que", .38), ("tu", .74), ("negocio", .90), ("trabaje", 1.40), ("mejor.", 1.98)]),
]
# Los tiempos por palabra son de la voz «claude» (medidos con Whisper). Con
# otra voz los subtítulos se reparten solos a lo largo de la frase.
VO_TIMINGS_FOR = "claude"

# Subtítulos discretos para quien ve sin sonido (Reels/TikTok arrancan mudos).
SUBTITULOS = True
SUBTITULOS_EN = ["vo1", "vo2", "vo3", "vo4"]   # en la solución hablan los rótulos; en el cierre, la frase

# ── Textos en pantalla ───────────────────────────────────────────────────
URL = "kiro.kirosolutionsco.workers.dev"  # dirección web oficial actual; cambiar cuando haya dominio propio

# Rótulos de E4 (los tres conceptos), cada uno entra con su palabra en la voz
CONCEPTOS = [
    ("Software a tu medida", 0.52),       # segundos desde vo6a
    ("Automatizaciones", 2.08),
    ("Agentes inteligentes", 3.72),
]

# Demo de E4 (mismo escenario de muestra que la landing; no es un cliente real).
# Sin el nombre de la marca: el agente se presenta solo como «Agente inteligente».
DEMO = dict(
    agente="Agente inteligente",
    negocio="Casa Ceiba",
    canal="WhatsApp",
    cliente1="Hola, ¿hay habitación para el sábado?",
    bot1="¡Hola! Sí, nos queda la habitación 8. ¿Te la reservo?",
    cliente2="Sí, por favor",
    confirmacion="Reserva confirmada · Hab. 8 · sáb",
    panel_titulo="Reservas",
    panel_sub="Casa Ceiba · vie a dom",
    filas=["Vie", "Sáb", "Dom"],
    columnas=["H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8"],
    ocupacion=[[1, 1, 0, 1, 1, 1, 0, 1],
               [1, 1, 1, 1, 1, 1, 1, 2],   # 2 = la que reserva Kiro
               [1, 0, 0, 1, 0, 1, 0, 0]],
)

# ── Composición ──────────────────────────────────────────────────────────
LOGO_SCALE = 0.40        # 1 unidad del SVG = 0,40 px → logo de ~710 px de ancho
LOGO_CENTER = (540, 880) # centro del logo completo (con «solutions»)
