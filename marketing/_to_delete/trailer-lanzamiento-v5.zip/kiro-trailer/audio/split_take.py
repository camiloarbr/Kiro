"""Corta una toma completa de narración (un solo archivo con todo el guion)
en las frases que usa el tráiler, y guarda los tiempos de cada palabra para
los subtítulos.

  python audio/split_take.py toma.mp3 audio/voz/carlos

Necesita faster-whisper (pip install faster-whisper). Escribe en la carpeta
destino 01-idea.mp3 … 06b-para-que.mp3 y words.json.
"""
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

SR = 48000
# (archivo, primera palabra de la frase); el orden es el del guion
SEGMENTS = [
    ("01-idea", "todo"),
    ("02-a-mano", "pero"),
    ("03-crecimiento", "cada"),
    ("04-otra-forma", "hay"),
    ("06a-creamos", "creamos"),
    ("06b-para-que", "para"),
    ("05-kiro", "kiro"),
]


def load(path, sr):
    raw = subprocess.run(["ffmpeg", "-v", "quiet", "-i", str(path), "-f", "f32le", "-ac", "1",
                          "-ar", str(sr), "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32)


def norm(w):
    return "".join(ch for ch in w.lower() if ch.isalpha() or ch in "áéíóúñü")


def main(src, dst):
    from faster_whisper import WhisperModel
    dst = Path(dst)
    dst.mkdir(parents=True, exist_ok=True)
    y = load(src, SR)
    y16 = load(src, 16000)
    m = WhisperModel("small", device="cpu", compute_type="int8")
    segs, _ = m.transcribe(y16, language="es", beam_size=5, word_timestamps=True,
                           initial_prompt="Kiro es una empresa de software.")
    words = [(w.word.strip(), w.start, w.end) for s in segs for w in s.words]
    # índice de la palabra donde empieza cada frase (buscando en orden)
    starts, i = [], 0
    for _, first in SEGMENTS:
        while norm(words[i][0]) != first:
            i += 1
        starts.append(i)
        i += 1
    env = np.convolve(np.abs(y), np.ones(480) / 480, "same")

    def quiet_point(a, b):
        """El instante más silencioso entre a y b (segundos)."""
        ia, ib = int(a * SR), max(int(a * SR) + 1, int(b * SR))
        return (ia + int(np.argmin(env[ia:ib]))) / SR

    bounds = [0.0]
    for k in range(1, len(starts)):
        prev_end = words[starts[k] - 1][2]
        nxt = words[starts[k]][1]
        bounds.append(quiet_point(prev_end, max(nxt, prev_end + 0.02)))
    bounds.append(len(y) / SR)
    out = {}
    for k, (name, _) in enumerate(SEGMENTS):
        a, b = bounds[k], bounds[k + 1]
        # recorta el silencio largo: deja 0,12 s antes de la primera palabra
        w0 = words[starts[k]][1]
        a = max(a, w0 - 0.12)
        last = starts[k + 1] - 1 if k + 1 < len(starts) else len(words) - 1
        b = min(b, words[last][2] + 0.45)
        seg = y[int(a * SR): int(b * SR)].copy()
        f = int(0.01 * SR)
        seg[:f] *= np.linspace(0, 1, f)
        seg[-f * 3:] *= np.linspace(1, 0, f * 3)
        wav = dst / f"{name}.wav"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-",
                        "-c:a", "libmp3lame", "-q:a", "1", str(dst / f"{name}.mp3")],
                       input=seg.astype(np.float32).tobytes(), check=True)
        out[name] = [(w, round(s - a, 2)) for (w, s, e) in words[starts[k]: last + 1]]
        print(f"{name}: {b - a:.2f} s  " + " ".join(w for w, _ in out[name]))
    (dst / "words.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
