"""E7: la firma. La interfaz se recoge, la celda reservada (que es el cursor)
vuelve a su sitio en el logo, la marca se arma de nuevo en un gesto rápido y
aparecen la frase y la llamada a la acción. Cierra un parpadeo."""
import skia

import config as cfg
from lib import ease as E
from lib import logo as L
from lib import timeline as TL
from lib.draw import draw_text, font, paint, text_width
from scenes import logo_build, system

C, T, S7 = cfg.C, cfg.T, TL.S7


def _home_rect():
    s = TL.CURSOR_PX
    return skia.Rect.MakeXYWH(TL.HOME[0] - s / 2, TL.HOME[1] - s / 2, s, s)


def _blink_alpha(t):
    b0, b1 = T["sting"], T["sting"] + 0.26
    if b0 <= t <= b1 + 0.05:
        return 1 - min(E.prog(t, b0, b0 + 0.04), 1 - E.prog(t, b1, b1 + 0.05))
    return 1.0


def _tagline(c, t, r):
    f = font("mont600", 40)
    for i, (txt, key) in enumerate(zip(cfg.TAGLINE, ("line1", "line2"))):
        k = E.out_cubic(E.prog(r, *S7[key]))
        if k <= 0:
            continue
        y = 1226 + i * 60
        tr = E.lerp(0.32, 0.16, E.out_quint(E.prog(r, *S7[key])))
        c.save()
        c.clipRect(skia.Rect.MakeLTRB(0, y - 46, 1080, y + 14))
        draw_text(c, txt, 540, y + (1 - k) * 40, f, C["white"], k, align="center", tracking=tr)
        c.restore()
    k = E.prog(r, *S7["cta"])
    if k > 0:
        draw_text(c, cfg.CTA, 540, 1420, font("mono400", 30), C["gray"], k, align="center", tracking=0.04)


def draw(c, t):
    if t < T["s7"]:
        return
    r = t - T["s7"]
    h0, h1 = S7["cursor_home"]
    if r < S7["rebuild"][0]:
        # la celda reservada viaja de vuelta y vuelve a ser el cursor
        k = E.in_out_expo(E.prog(r, h0, h1))
        a, b = system.TARGET_RECT, _home_rect()
        rect = skia.Rect.MakeLTRB(E.lerp(a.left(), b.left(), k), E.lerp(a.top(), b.top(), k),
                                  E.lerp(a.right(), b.right(), k), E.lerp(a.bottom(), b.bottom(), k))
        rad = 12 * (1 - k)
        c.drawRRect(skia.RRect.MakeRectXY(rect, rad, rad), paint(C["violet"]))
        return
    u = E.lerp(TL.S5["hop"][1], TL.S5_DONE, E.prog(r, *S7["rebuild"]))
    sol = E.out_cubic(E.prog(r, *S7["solutions"]))
    logo_build.draw_build(c, u, hop=False, solutions=sol, cursor_alpha=_blink_alpha(t))
    _tagline(c, t, r)
