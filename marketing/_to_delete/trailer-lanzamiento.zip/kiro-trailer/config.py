"""Configuración editable del tráiler «Todo comienza con un punto».

Todo lo que normalmente se querría cambiar vive aquí: tiempos, textos,
colores, voz y salida. La animación (render.py) y el audio (audio/build_audio.py)
leen ESTE archivo, así que un cambio de tiempo mueve imagen y sonido juntos.
"""

# ── Salida ───────────────────────────────────────────────────────────────
W, H = 1080, 1920
FPS = 30
DURATION = 41.0          # segundos totales (incluye la cola de silencio)

# ── Voz ──────────────────────────────────────────────────────────────────
# Carpeta dentro de audio/voz/: "brian" (principal) o "george" (alternativa).
VOICE = "brian"

# ── Paleta oficial (manual de marca v1.0) ────────────────────────────────
C = dict(
    violet="#8B2CF5",       # Kiro Violet: cursor y acciones de Kiro (máx. 10 %)
    violet_dark="#5B17B8",
    violet_light="#B07CFF", # texto de acento sobre negro
    black="#0C0A10",        # fondo
    graphite="#1F1A27",     # superficies
    graphite_2="#2A2433",   # superficies elevadas (derivado de grafito)
    gray="#918A9E",         # texto secundario
    white="#F6F4FA",        # texto
    lav="#D9C4FF",          # lavanda media (extensión web aprobada)
)

# ── Línea de tiempo (segundos) ───────────────────────────────────────────
T = dict(
    cursor_on=1.20,     # E1: aparece el cuadrado
    vo1=2.20,           # «Todo negocio empieza con una idea.»
    s2=4.60,            # E2: el cuadrado empieza a moverse
    vo2=5.30,           # «Pero cuando todo depende de hacerlo a mano…»
    s3=9.60,            # E3: sobrecarga
    vo3=10.00,          # «El crecimiento no debería significar más complicaciones.»
    slow=13.60,         # el movimiento empieza a frenarse
    freeze=15.40,       # último sonido: todo se detiene
    s4=15.40,           # E4: silencio, se retira todo
    vo4=17.00,          # «Hay otra forma.»
    s5=18.90,           # E5: transformación cuadrado → kiro
    logo_done=21.90,    # la palabra queda completa (impacto)
    vo5=22.45,          # «Kiro.»
    s6=24.00,           # E6: el sistema en acción
    vo6a=24.70,         # «Creamos software a tu medida… automatizaciones… y agentes inteligentes.»
    vo6b=31.00,         # «Para que tu negocio trabaje mejor.»
    s7=33.40,           # E7: la firma
    vo7=34.70,          # «Kiro. Software a la medida que trabaja por ti.»
    sting=39.75,        # firma sonora final (parpadeo del cursor)
)

# ── Narración ────────────────────────────────────────────────────────────
# (archivo en audio/voz/<VOICE>/, cue de inicio, texto, palabras con tiempos
#  relativos de la toma «brian» medidos con ElevenLabs Scribe; con otra voz
#  los subtítulos se reparten solos a lo largo de la frase).
VO = [
    ("01-idea.mp3", "vo1", "Todo negocio empieza con una idea.",
     [("Todo", .14), ("negocio", .48), ("empieza", 1.04), ("con", 1.52), ("una", 1.70), ("idea.", 1.88)]),
    ("02-a-mano.mp3", "vo2", "Pero cuando todo depende de hacerlo a mano…",
     [("Pero", .12), ("cuando", .42), ("todo", .94), ("depende", 1.20), ("de", 2.46), ("hacerlo", 2.54), ("a", 3.0), ("mano…", 3.12)]),
    ("03-crecimiento.mp3", "vo3", "El crecimiento no debería significar más complicaciones.",
     [("El", .20), ("crecimiento", .36), ("no", 1.48), ("debería", 1.66), ("significar", 2.20), ("más", 3.82), ("complicaciones.", 4.08)]),
    ("04-otra-forma.mp3", "vo4", "Hay otra forma.",
     [("Hay", .12), ("otra", .48), ("forma.", .84)]),
    ("05-kiro.mp3", "vo5", "Kiro.", [("Kiro.", .22)]),
    ("06a-creamos.mp3", "vo6a", "Creamos software a tu medida, automatizaciones y agentes inteligentes",
     [("Creamos", .12), ("software", .68), ("a", 1.36), ("tu", 1.48), ("medida,", 1.62), ("automatizaciones", 2.72), ("y", 4.44), ("agentes", 4.56), ("inteligentes", 5.16)]),
    ("06b-para-que.mp3", "vo6b", "para que tu negocio trabaje mejor.",
     [("para", .10), ("que", .34), ("tu", .50), ("negocio", .66), ("trabaje", 1.32), ("mejor.", 1.78)]),
    ("07-firma.mp3", "vo7", "Kiro. Software a la medida que trabaja por ti.",
     [("Kiro.", .16), ("Software", 1.22), ("a", 1.92), ("la", 2.0), ("medida", 2.14), ("que", 3.02), ("trabaja", 3.16), ("por", 3.74), ("ti.", 3.96)]),
]

# Subtítulos discretos para quien ve sin sonido (Reels/TikTok arrancan mudos).
SUBTITULOS = True
SUBTITULOS_EN = ["vo1", "vo2", "vo3", "vo4"]   # en E6 hablan los rótulos y en E7 la firma

# ── Textos en pantalla ───────────────────────────────────────────────────
TAGLINE = ["SOFTWARE A LA MEDIDA", "QUE TRABAJA POR TI."]
CTA = "Escríbenos  ·  link en la bio"     # cambiar por el dominio cuando exista

# Rótulos de E6 (los tres conceptos), cada uno entra con su palabra en la voz
CONCEPTOS = [
    ("Software a tu medida", 0.68),       # segundos desde vo6a
    ("Automatizaciones", 2.72),
    ("Agentes inteligentes", 4.56),
]

# Demo de E6 (mismo escenario de muestra que la landing; no es un cliente real)
DEMO = dict(
    negocio="Casa Ceiba",
    canal="WhatsApp",
    cliente1="Hola, ¿hay habitación para el sábado?",
    bot1="¡Hola! Sí, nos queda la habitación 8. ¿Te la reservo?",
    cliente2="Sí, por favor",
    confirmacion="Reserva confirmada · Hab. 8 · sáb",
    panel_titulo="Reservas",
    panel_sub="Casa Ceiba · vie a dom",
    filas=["Vie", "Sáb", "Dom"],
    columnas=["H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8"],
    ocupacion=[[1, 1, 0, 1, 1, 1, 0, 1],
               [1, 1, 1, 1, 1, 1, 1, 2],   # 2 = la que reserva Kiro
               [1, 0, 0, 1, 0, 1, 0, 0]],
)

# ── Composición ──────────────────────────────────────────────────────────
LOGO_SCALE = 0.40        # 1 unidad del SVG = 0,40 px → logo de ~710 px de ancho
LOGO_CENTER = (540, 880) # centro del logo completo (con «solutions»)
