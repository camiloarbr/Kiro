# Tráiler de lanzamiento de Kiro — «Todo comienza con un punto»

Video vertical 1080 × 1920, 30 fps, H.264 + AAC, para Reels y TikTok.

**Versión actual: v3** (`out/kiro-trailer-v3.mp4`, 38 s). El espectador
descubre primero el problema, después la solución y al final la marca: el logo
aparece una sola vez, en los últimos segundos, y el narrador solo dice «Kiro».

| Escena | Tiempo | Qué pasa |
|---|---|---|
| 1 Intriga | 0–5 s | El cuadrado violeta aparece en el centro de la pantalla. «Todo negocio empieza con una idea.» |
| 2 Tensión | 5–14,4 s | Sale del centro y activa una hoja de cálculo (cuadrícula completa), chats, pendientes y registros que se acumulan. «Pero cuando todo depende de hacerlo a mano, cada tarea se convierte en otra complicación.» |
| 3 Pausa | 14,4–18 s | Corte seco, todo se retira y el cuadrado vuelve al centro. «Hay otra forma.» |
| 4 Solución | 18–28 s | El cuadrado traza la guía y ordena el espacio; se vuelve la respuesta del agente y la celda reservada. Sin marca. |
| 5 Revelación | 28–35 s | La interfaz converge en el cuadrado, que se queda solo y se transforma en «kiro» (única vez). «Kiro.» |
| 6 Cierre | 35–38 s | Logo quieto y la dirección web. Parpadeo y firma sonora. |

Versiones anteriores, intactas: `out/kiro-trailer.mp4` (v1) y `out/kiro-trailer-v2.mp4`.

## Archivos

| Ruta | Qué es |
|---|---|
| `out/kiro-trailer-v3.mp4` | **Video actual (v3)** |
| `out/hoja-de-contacto-v3.png` | Un fotograma por segundo de la v3 |
| `out/kiro-trailer-v2.mp4`, `out/hoja-de-contacto-v2.png` | v2 (referencia) |
| `out/kiro-trailer.mp4` | v1 (referencia; no se sobrescribe) |
| `out/animatic.mp4`, `out/hoja-de-contacto.png` | Pruebas de la v1 |
| `audio/voz/claude/` | **Narración usada en la v3** (Piper es_MX, masculina, español latino neutro) |
| `audio/voz/ald/` | Alternativa abierta (Piper es_MX, masculina, más clara) |
| `audio/tts_piper.py` | Genera las dos voces anteriores (textos y ritmo de cada frase) |
| `audio/voz/brian/`, `audio/voz/george/` | Voces de ElevenLabs de la v1–v2 (acento anglo) |
| `audio/voz/pruebas/` | Las dos pruebas cortas de voz |
| `audio/stems/` | `voz.wav`, `musica.wav`, `efectos.wav`, `mezcla.wav` |
| `config.py` | **Todo lo editable**: tiempos, textos, colores, voz, CTA |
| `lib/logo.py` | Lee la geometría del logo oficial desde `brand/` |
| `lib/timeline.py` | Eventos derivados (movimientos, cues de sonido) |
| `scenes/` | Una pieza por escena: cursor, trabajo manual (E2–E4), transformación (E5), sistema (E6), firma (E7), subtítulos |
| `audio/build_audio.py` | Diseño sonoro, música, mezcla y sonoridad |

## Cómo se ejecuta

Requisitos: Python 3.11+ y FFmpeg en el PATH.

```bash
pip install -r requirements.txt
python build.py              # audio + video → out/kiro-trailer-<VERSION>.mp4  (≈1 min)
python build.py --animatic   # solo 0–24 s → out/animatic.mp4
python render.py --frames 2.5 21.9 38   # fotogramas sueltos en out/frames/
python audio/build_audio.py  # solo rehace el audio
```

El render es determinista: no hay azar ni temporizadores. Imagen y sonido
leen la misma línea de tiempo (`config.T` → `lib/timeline.py`), así que si
mueves un tiempo en `config.py`, se mueven juntos.

## Cambios frecuentes

- **Cambiar de voz:** `VOICE = "ald"` (o `"brian"`, `"george"`) en `config.py` y `python build.py`.
- **Regenerar la voz abierta:** descarga `es_MX-claude-high.onnx` y
  `es_MX-ald-medium.onnx` (con sus `.onnx.json`) de
  huggingface.co/rhasspy/piper-voices (carpeta `es/es_MX`), `pip install
  piper-tts` y corre `python audio/tts_piper.py --modelos <carpeta>`.
- **Otra toma de voz:** reemplaza el `.mp3` en `audio/voz/brian/` con el
  mismo nombre. Si la nueva toma dura distinto, ajusta el cue en `config.T`.
- **Dirección web del cierre:** `URL` en `config.py` (hoy
  kiro.kirosolutionsco.workers.dev).
- **Nueva versión sin pisar la anterior:** cambia `VERSION` en `config.py`.
- **Subtítulos:** `SUBTITULOS = False` los quita.
- **Textos de la demo** (Casa Ceiba, mensajes, panel): `DEMO` en `config.py`.

## Decisiones de producción

- **Logo:** no se redibujó ninguna letra. `lib/logo.py` lee los trazados de
  `brand/kiro-logo-principal-negativo.svg` (el del manual) y la animación solo
  decide cómo se revelan. El fotograma final es idéntico al SVG oficial,
  incluido el gris `#B9B3C4` de «solutions».
- **Transformación:** el cuadrado salta, se duplica y su copia cae para
  escribir el palo de la «i»; los bordes de ese palo se extienden como línea
  base y altura x; sobre esas guías se levantan la K, la r y la o, cada una con
  un filo violeta en el borde que avanza; las guías vuelven a la «i» y el
  cursor parpadea una vez. La cámara se acerca en el silencio y se aleja
  mientras se arma la palabra.
- **Violeta = Kiro actuando:** en la demo, el cuadrado se expande y se vuelve
  la respuesta del agente, luego viaja por el conector y termina siendo la
  celda reservada. En el cierre esa celda vuelve a su sitio en el logo.
- **Render:** Python + Skia (dibujo vectorial con antialiasing) y FFmpeg. Se
  eligió sobre Remotion porque el repo de la landing es Astro (no React) y
  así no hace falta un navegador para renderizar.
- **Sonido:** música y efectos se sintetizan en `audio/build_audio.py` con
  NumPy: son originales, sin licencias de terceros. La firma sonora es un
  «ping» de cursor (La5) sobre un acorde abierto de Re; suena al aparecer el
  cuadrado, cuando la palabra queda completa y al cerrar. En el freeze de E4
  el sonido se corta en seco (sin cola de reverberación) y la música baja
  sola cuando habla el narrador. Mezcla final a −14 LUFS, pico −1,5 dBFS.
- **Voz:** ElevenLabs v3 a través de CoDesign (IMG.LY). Se probaron Brian y
  George; quedó Brian por ser más grave (≈90 Hz frente a ≈125 Hz) y más
  pausado. Cada frase es un archivo aparte, con indicaciones de actuación.
  Las transcripciones confirmaron que el español sale limpio y que «Kiro» se
  pronuncia bien.

## Limitaciones y pendientes

1. **Voz.** La v3 usa una voz abierta (Piper es_MX «claude», licencia
   Apache-2.0): español latino neutro y sin acento anglo, pero menos expresiva
   que ElevenLabs y con un leve timbre sintético. Para una interpretación más
   humana con el mismo acento: recargar créditos de IMG.LY y generar con
   **MiniMax Voice Design** (se le describe la voz: «hombre latinoamericano,
   español neutro, cálido y grave») o grabar a un locutor colombiano. Cualquier
   toma nueva va en `audio/voz/<nombre>/` con los mismos nombres de archivo.
2. **Licencias.** Las voces Piper son de uso libre (claude: Apache-2.0; ald:
   Unlicense). Las tomas de ElevenLabs (v1–v2) dependen de los términos de
   IMG.LY/ElevenLabs.
3. **Dominio.** El cierre muestra la dirección de workers.dev; cámbiala en
   `URL` (o déjala vacía para que solo quede el logo).
4. **Demo.** «Casa Ceiba» es un negocio de muestra, igual que en la landing.
