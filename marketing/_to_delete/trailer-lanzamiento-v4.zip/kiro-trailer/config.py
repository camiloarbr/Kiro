"""Configuración editable del tráiler «Todo comienza con un punto».

Todo lo que normalmente se querría cambiar vive aquí: tiempos, textos,
colores, voz y salida. La animación (render.py) y el audio (audio/build_audio.py)
leen ESTE archivo, así que un cambio de tiempo mueve imagen y sonido juntos.
"""

# ── Salida ───────────────────────────────────────────────────────────────
VERSION = "v4"           # nombre del render: out/kiro-trailer-v4.mp4 (no pisa versiones anteriores)
W, H = 1080, 1920
FPS = 30
DURATION = 40.3          # segundos totales (incluye la cola de silencio)

# ── Voz ──────────────────────────────────────────────────────────────────
# Carpeta dentro de audio/voz/. v4: «brian» (ElevenLabs v3), la de la v2.
# Alternativas: «george» (ElevenLabs) y las voces abiertas en español latino
# «claude» y «ald» (Piper, audio/tts_piper.py; las usó la v3).
VOICE = "brian"

# ── Paleta oficial (manual de marca v1.0) ────────────────────────────────
C = dict(
    violet="#8B2CF5",       # Kiro Violet: cursor y acciones de Kiro (máx. 10 %)
    violet_dark="#5B17B8",
    violet_light="#B07CFF", # texto de acento sobre negro
    black="#0C0A10",        # fondo
    graphite="#1F1A27",     # superficies
    graphite_2="#2A2433",   # superficies elevadas (derivado de grafito)
    gray="#918A9E",         # texto secundario
    white="#F6F4FA",        # texto
    lav="#D9C4FF",          # lavanda media (extensión web aprobada)
)

# ── Línea de tiempo (segundos) ───────────────────────────────────────────
# v2: el logo solo aparece al final. Orden: problema → solución → marca.
T = dict(
    cursor_on=1.60,     # E1 intriga: aparece el cuadrado, en el centro
    vo1=4.40,           # «Todo negocio empieza con una idea.» (v4: 2 s más de silencio antes)
    s2=7.00,            # E2 tensión: el cuadrado empieza a activar cosas
    vo2=7.50,           # «Pero cuando todo depende de hacerlo a mano…»
    s3=11.40,           # la complejidad se acumula
    vo3=11.80,          # «El crecimiento no debería significar más complicaciones.»
    slow=15.40,         # el movimiento empieza a frenarse
    freeze=17.10,       # corte: todo se detiene
    s4=17.10,           # E3 pausa: se retira todo, silencio real
    vo4=18.60,          # «Hay otra forma.»
    s6=20.60,           # E4 la solución: el cuadrado ordena el espacio y trabaja
    vo6a=21.40,         # «Creamos software a tu medida… automatizaciones… y agentes inteligentes.»
    vo6b=27.75,         # «Para que tu negocio trabaje mejor.»
    rv=31.40,           # E5 revelación: la interfaz converge en el cuadrado
    s5=33.80,           # el cuadrado empieza a transformarse (única vez)
    logo_done=36.80,    # «kiro» queda completo (impacto)
    vo5=37.45,          # «Kiro.»  (el cierre solo dice el nombre)
    close=38.40,        # el logo queda quieto (dirección web solo si config.URL no está vacía)
    sting=38.90,        # firma sonora final (parpadeo del cursor)
)

# ── Narración ────────────────────────────────────────────────────────────
# (archivo en audio/voz/<VOICE>/, cue de inicio, texto, palabras con tiempos
#  relativos de la toma «brian» medidos con ElevenLabs Scribe; con otra voz
#  los subtítulos se reparten solos a lo largo de la frase).
VO = [
    ("01-idea.mp3", "vo1", "Todo negocio empieza con una idea.",
     [("Todo", .14), ("negocio", .48), ("empieza", 1.04), ("con", 1.52), ("una", 1.70), ("idea.", 1.88)]),
    ("02-a-mano.mp3", "vo2", "Pero cuando todo depende de hacerlo a mano…",
     [("Pero", .12), ("cuando", .42), ("todo", .94), ("depende", 1.20), ("de", 2.46), ("hacerlo", 2.54), ("a", 3.0), ("mano…", 3.12)]),
    ("03-crecimiento.mp3", "vo3", "El crecimiento no debería significar más complicaciones.",
     [("El", .20), ("crecimiento", .36), ("no", 1.48), ("debería", 1.66), ("significar", 2.20), ("más", 3.82), ("complicaciones.", 4.08)]),
    ("04-otra-forma.mp3", "vo4", "Hay otra forma.",
     [("Hay", .12), ("otra", .48), ("forma.", .84)]),
    ("05-kiro.mp3", "vo5", "Kiro.", [("Kiro.", .22)]),
    ("06a-creamos.mp3", "vo6a", "Creamos software a tu medida, automatizaciones y agentes inteligentes",
     [("Creamos", .12), ("software", .68), ("a", 1.36), ("tu", 1.48), ("medida,", 1.62), ("automatizaciones", 2.72), ("y", 4.44), ("agentes", 4.56), ("inteligentes", 5.16)]),
    ("06b-para-que.mp3", "vo6b", "para que tu negocio trabaje mejor.",
     [("para", .10), ("que", .34), ("tu", .50), ("negocio", .66), ("trabaje", 1.32), ("mejor.", 1.78)]),
]
# Tiempos por palabra medidos sobre la voz «brian» (ElevenLabs Scribe). Con
# otra voz los subtítulos se reparten solos a lo largo de la frase.
VO_TIMINGS_FOR = "brian"

# Subtítulos discretos para quien ve sin sonido (Reels/TikTok arrancan mudos).
SUBTITULOS = True
SUBTITULOS_EN = ["vo1", "vo2", "vo3", "vo4"]   # en la solución hablan los rótulos; en el cierre, la frase

# ── Textos en pantalla ───────────────────────────────────────────────────
URL = ""   # v4: sin dirección web; el cierre es solo el logo. Para mostrarla: "kiro.kirosolutionsco.workers.dev"

# Rótulos de E4 (los tres conceptos), cada uno entra con su palabra en la voz
CONCEPTOS = [
    ("Software a tu medida", 0.68),       # segundos desde vo6a (voz brian)
    ("Automatizaciones", 2.72),
    ("Agentes inteligentes", 4.56),
]

# Demo de E4 (mismo escenario de muestra que la landing; no es un cliente real).
# Sin el nombre de la marca: el agente se presenta solo como «Agente inteligente».
DEMO = dict(
    agente="Agente inteligente",
    negocio="Casa Ceiba",
    canal="WhatsApp",
    cliente1="Hola, ¿hay habitación para el sábado?",
    bot1="¡Hola! Sí, nos queda la habitación 8. ¿Te la reservo?",
    cliente2="Sí, por favor",
    confirmacion="Reserva confirmada · Hab. 8 · sáb",
    panel_titulo="Reservas",
    panel_sub="Casa Ceiba · vie a dom",
    filas=["Vie", "Sáb", "Dom"],
    columnas=["H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8"],
    ocupacion=[[1, 1, 0, 1, 1, 1, 0, 1],
               [1, 1, 1, 1, 1, 1, 1, 2],   # 2 = la que reserva Kiro
               [1, 0, 0, 1, 0, 1, 0, 0]],
)

# ── Composición ──────────────────────────────────────────────────────────
LOGO_SCALE = 0.40        # 1 unidad del SVG = 0,40 px → logo de ~710 px de ancho
LOGO_CENTER = (540, 880) # centro del logo completo (con «solutions»)
